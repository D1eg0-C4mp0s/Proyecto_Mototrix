package com.edu.unab.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.edu.unab.model.entity.Vehiculo;
import com.edu.unab.model.service.VehiculoService;

@RestController
@RequestMapping("/api/vehiculos")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
public class VehiculoController {

	@Autowired
	private VehiculoService vehiculoservice;
	
	@PostMapping
	public Vehiculo guardar(@RequestBody Vehiculo vehiculo) {
		return vehiculoservice.save(vehiculo);
	}
	
	@PutMapping
	public Vehiculo actualizar(@RequestBody Vehiculo vehiculo) {
		Vehiculo vBD=vehiculoservice.findById(vehiculo.getIdVehiculos()).get();
		vBD.setPlaca(vehiculo.getPlaca());
		vBD.setMarca(vehiculo.getMarca());
		vBD.setReferencia(vehiculo.getReferencia());
		vBD.setModelo(vehiculo.getModelo());
		vBD.setEstado(vehiculo.getEstado());
		vBD.setKilometros_rec(vehiculo.getKilometros_rec());
		return vehiculoservice.save(vBD);
	}
	
	@GetMapping("/{id}")
	public Optional<Vehiculo>buscarporID(@PathVariable Integer id){
		return vehiculoservice.findById(id);
	}
	
	@GetMapping("/listar")
	public Iterable<Vehiculo>listarTodos(){
		return vehiculoservice.findAll();
	}
	
	@DeleteMapping("{id}")
	public void eliminar(@PathVariable Integer id) {
		vehiculoservice.deleteById(id);
	}
}
