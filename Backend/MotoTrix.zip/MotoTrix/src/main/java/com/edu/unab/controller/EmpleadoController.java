package com.edu.unab.controller;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.edu.unab.model.entity.Empleado;
import com.edu.unab.model.service.EmpleadoService;

@RestController
@RequestMapping("/api/empleado")
@CrossOrigin(origins = "*", methods = {RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT, RequestMethod.DELETE})
public class EmpleadoController {

	@Autowired
	private EmpleadoService empleadoservice;
	
	@PostMapping
	public Empleado guardar(@RequestBody Empleado empleado) {
		return empleadoservice.save(empleado);
	}
	
	@PostMapping("/actualizar")
	public Empleado actualizar(@RequestBody Empleado empleado) {
		Empleado eEBD=empleadoservice.findById(empleado.getIdEmpleado()).get();
		eEBD.setNombre(empleado.getNombre());
		eEBD.setTelefono(empleado.getTelefono());
		eEBD.setTipo(empleado.getTipo());
		eEBD.setSalario(empleado.getSalario());
		return empleadoservice.save(eEBD);
	}
	
	@GetMapping("/{id}")
	public Optional<Empleado>buscarporID(@PathVariable Integer id){
		return empleadoservice.findById(id);
	}
	
	@GetMapping("/listar")
	public Iterable<Empleado>listarTodos(){
		return empleadoservice.findAll();
	}
	
	@DeleteMapping("{id}")
	public void eliminar(@PathVariable Integer id) {
		empleadoservice.deleteById(id);
	}
}
