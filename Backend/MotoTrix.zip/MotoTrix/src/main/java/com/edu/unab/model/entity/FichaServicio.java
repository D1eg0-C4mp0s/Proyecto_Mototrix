package com.edu.unab.model.entity;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="ficha_de_servicio")
public class FichaServicio {

	@Id
	@Column(name = "idficha_servicios")
	private Integer idFicha = 0;
	@ManyToOne
	@JoinColumn(name = "idcliente")
	private Cliente cliente;
	@ManyToOne
	@JoinColumn(name = "idempleado")
	private Empleado empleado;
	@ManyToOne
	@JoinColumn(name = "idvehiculo")
	private Vehiculo vehiculo;
	@SuppressWarnings("deprecation")
	@Column(name = "fecha_servicio")
	private Date fechaServicio = new Date(2000, 1, 1);
	@Column(name = "estado")
	private String estado = "Ingresado";
	@Column(name = "costo")
	private Double costo = 0.0;
	
	public FichaServicio() {
	}

	public FichaServicio(Integer idFicha, Cliente cliente, Empleado empleado, Vehiculo vehiculo, Date fechaServicio,
			String estado, Double costo) {
		this.idFicha = idFicha;
		this.cliente = cliente;
		this.empleado = empleado;
		this.vehiculo = vehiculo;
		this.fechaServicio = fechaServicio;
		this.estado = estado;
		this.costo = costo;
	}

	public Integer getIdFicha() {
		return idFicha;
	}

	public void setIdFicha(Integer idFicha) {
		this.idFicha = idFicha;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Empleado getEmpleado() {
		return empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public Vehiculo getVehiculo() {
		return vehiculo;
	}

	public void setVehiculo(Vehiculo vehiculo) {
		this.vehiculo = vehiculo;
	}

	public Date getFechaServicio() {
		return fechaServicio;
	}

	public void setFechaServicio(Date fechaServicio) {
		this.fechaServicio = fechaServicio;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Double getCosto() {
		return costo;
	}

	public void setCosto(Double costo) {
		this.costo = costo;
	}

	@Override
	public String toString() {
		return "FichaServicio [idFicha=" + idFicha + ", cliente=" + cliente + ", empleado=" + empleado + ", vehiculo="
				+ vehiculo + ", fechaServicio=" + fechaServicio + ", estado=" + estado + ", costo=" + costo + "]";
	}
	
}
