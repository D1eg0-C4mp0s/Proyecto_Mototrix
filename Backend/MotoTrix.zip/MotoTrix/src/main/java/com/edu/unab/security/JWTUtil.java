package com.edu.unab.security;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//@Component
public class JWTUtil {

	/*@Value("${security.jwt.secret}")
	private String key;
	
	@Value("${security.jwt.issuer}")
	private String issuer;
	
	@Value("${security.jwt.ttlMillis}")
	private Integer ttlMillis;
	
	public Integer crearToken(String contraseña, Integer id) {
	}*/
}
